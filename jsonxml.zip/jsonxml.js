"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var xsd2ts_1 = require("xsd2ts");
xsd2ts_1.generateTemplateClassesFromXSD('./OTA_HotelResNotifRQ.xsd');
