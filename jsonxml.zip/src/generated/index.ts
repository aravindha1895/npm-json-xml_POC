/***********
generated template classes for ./OTA_HotelResNotifRQ1.xsd 2020-8-14 22:22:07
***********/





import * as xmlns from "";

export class OTA_HotelResNotifRQ1 {
    public oTA_HotelResNotifRQ: OTA_HotelResNotifRQ;

    public constructor(props?: OTA_HotelResNotifRQ1) {
        this["@class"] = ".OTA_HotelResNotifRQ1";

        (<any>Object).assign(this, <any> props);
    }
}

export class OTA_HotelResNotifRQ {
    public ResStatus: string;
    public HoldDuration: string;

    public constructor(props?: OTA_HotelResNotifRQ) {
        this["@class"] = ".OTA_HotelResNotifRQ";

        (<any>Object).assign(this, <any> props);
    }
}
