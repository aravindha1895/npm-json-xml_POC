"use strict";
/***********
generated template classes for ./OTA_HotelResNotifRQ1.xsd 2020-8-14 22:22:07
***********/
Object.defineProperty(exports, "__esModule", { value: true });
exports.OTA_HotelResNotifRQ = exports.OTA_HotelResNotifRQ1 = void 0;
var OTA_HotelResNotifRQ1 = /** @class */ (function () {
    function OTA_HotelResNotifRQ1(props) {
        this["@class"] = ".OTA_HotelResNotifRQ1";
        Object.assign(this, props);
    }
    return OTA_HotelResNotifRQ1;
}());
exports.OTA_HotelResNotifRQ1 = OTA_HotelResNotifRQ1;
var OTA_HotelResNotifRQ = /** @class */ (function () {
    function OTA_HotelResNotifRQ(props) {
        this["@class"] = ".OTA_HotelResNotifRQ";
        Object.assign(this, props);
    }
    return OTA_HotelResNotifRQ;
}());
exports.OTA_HotelResNotifRQ = OTA_HotelResNotifRQ;
