import {generateTemplateClassesFromXSD} from "xsd2ts";
generateTemplateClassesFromXSD('./OTA_HotelResNotifRQ.xsd');